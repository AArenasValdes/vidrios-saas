VENTORA — Logo refinado final

Este pack conserva la base visual acordada:
- ventana/marco de aluminio como lectura principal
- trayectoria ascendente integrada como lectura secundaria
- sin flecha literal
- sin cubo 3D
- sin V protagonista
- tipografía editable en SVG

Archivos:
- ventora-logo-horizontal-principal.svg: versión principal sin subtítulo.
- ventora-logo-horizontal-comercial.svg: versión con subtítulo.
- ventora-logo-horizontal-dark-preview.svg: previsualización sobre fondo oscuro.
- ventora-isotipo-transparente.svg: símbolo solo, fondo transparente.
- ventora-isotipo-app-dark.svg: símbolo para PWA/app/redes con fondo oscuro.
- ventora-logo-monocromatico.svg: versión blanca/plata sin azul.
- ventora-logo-fondo-claro.svg: versión para fondo blanco.

Recomendación:
Abrir en Figma/Illustrator/Inkscape y convertir el texto VENTORA a contornos/outlines cuando se cierre la versión final.
